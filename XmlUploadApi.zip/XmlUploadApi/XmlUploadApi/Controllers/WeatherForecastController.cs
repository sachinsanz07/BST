using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;
using System.Data.SqlClient;
using static Azure.Core.HttpHeader;
using Dapper;

namespace XmlUploadApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            ""
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;

            
        }

       

        [HttpPost("upload")]
        public async Task<IActionResult> UploadData(string employeeData)
        {
            var connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\376318\\Documents\\XMLUPLOAD.mdf;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    Console.WriteLine("Connection successful!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Connection failed: {ex.Message}");
                }
            }

            if (string.IsNullOrEmpty(employeeData))
            {
                return BadRequest("No data provided.");
            }

            try
            {

                var employees = new List<Employee>();
                var employeeEntries = employeeData.Split('^', StringSplitOptions.RemoveEmptyEntries);

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (var entry in employeeEntries)
                    {
                        var details = entry.Split('~', StringSplitOptions.RemoveEmptyEntries);
                        if (details.Length != 6)
                        {
                            return BadRequest("Invalid employee data format.");
                        }

                        var emp = new Employee
                        {
                           
                            Name = details[0],
                            ID = details[1],
                            Contact = details[2],
                            BloodGroup = details[3],
                            Age = int.Parse(details[4]),
                            Gender = details[5]
                        };

                        var checkQuery = "SELECT COUNT(*) FROM EMPLOYEE_DATA WHERE Id = @ID";
                        var existingCount = await connection.ExecuteScalarAsync<int>(checkQuery, new { ID = emp.ID });

                        if (existingCount > 0)
                        {
                            return Ok(new { Message = " Already exists Employee with ID "+emp.ID+""});

                        }
                        else
                        {
                            employees.Add(emp);

                            var query = "INSERT INTO EMPLOYEE_DATA ( Id,Name, Contact, BloodGroup, Age, Gender) VALUES ( @ID , @Name, @Contact, @BloodGroup, @Age, @Gender)";

                            var parameters = new { Id = emp.ID, Name = emp.Name, Contact = emp.Contact, BloodGroup = emp.BloodGroup, Age = emp.Age, Gender = emp.Gender };
                            var res = await connection.ExecuteAsync(query, parameters);
                        }
                      
                    }
                }


                return Ok(new { Message = "Data uploaded and processed successfully!", Employees = employees });

            }
            catch (FormatException formatEx)
            {
                return BadRequest($"Error processing the data: {formatEx.Message}");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        [HttpGet("employees")]
        public async Task<IActionResult> GetEmployees()
        {
            var connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\376318\\Documents\\XMLUPLOAD.mdf;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                var checkQuery = "SELECT * FROM EMPLOYEE_DATA ORDER BY ID DESC";

                try
                {

                    await connection.OpenAsync();
                    var employees = await connection.QueryAsync<Employee>(checkQuery); 

                    if (employees.Any())
                    {
                        return Ok(employees);
                    }
                    else
                    {
                        return Ok(new { Message = "No employees found." });
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }
        public class Employee
        {

            public string Name { get; set; }
            public string ID { get; set; }
            public string Contact { get; set; }
            public string BloodGroup { get; set; }
            public int Age { get; set; }
            public string Gender { get; set; }
        }

    }
}

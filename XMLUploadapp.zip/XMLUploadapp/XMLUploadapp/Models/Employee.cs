﻿namespace XMLUploadapp.Models
{
    public class Employee
    {

        public string Name { get; set; }
        public string Id { get; set; }
        public string Contact { get; set; }
        public string BloodGroup { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }

    }
}

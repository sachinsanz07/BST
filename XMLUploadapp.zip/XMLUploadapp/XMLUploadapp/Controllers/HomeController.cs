using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using System.Xml;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;
using System.Security.Policy;
using XMLUploadapp.Models;
using System.Xml.Serialization;

namespace XmlUploadApp.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Upload()
        {

            return View();
        }
        private static readonly HttpClient client = new HttpClient();
        
        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile xmlFile)
        {
            if (xmlFile != null && xmlFile.Length > 0)
            {
                if (xmlFile == null || xmlFile.Length == 0)
                {
                    ViewBag.Message = "No file uploaded.";
                    return View();
                }

                if (Path.GetExtension(xmlFile.FileName).ToLower() != ".xml")
                {
                    ViewBag.Message = "Uploaded file is not an XML file.";
                    return View();
                }

                try
                {
                    using (var stream = new MemoryStream())
                    {
                        xmlFile.CopyTo(stream);
                        stream.Position = 0; 

                        using (var reader = new StreamReader(stream))
                        {
                            string xmlContent = reader.ReadToEnd().Trim(); 
                            XDocument xmlDoc = XDocument.Parse(xmlContent); 

                            var employees = new List<Employee>();
                            string empdata = "";
                            foreach (var employee in xmlDoc.Descendants("Employee"))
                            {
                                var name = employee.Element("Name")?.Value;
                                var id = employee.Element("ID")?.Value;
                                var contact = employee.Element("Contact")?.Value;
                                var bloodGroup = employee.Element("BloodGroup")?.Value;
                                var age = int.Parse(employee.Element("Age")?.Value);
                                var gender = employee.Element("Gender")?.Value;

                                employees.Add(new Employee
                                {
                                    Name = name,
                                    ID = id,
                                    Contact = contact,
                                    BloodGroup = bloodGroup,
                                    Age = age,
                                    Gender = gender
                                });

                                empdata += $"{name}~{id}~{contact}~{bloodGroup}~{age}~{gender}^"; // Use ^ as a separator


                            }


                            var url = $"http://localhost:53329/WeatherForecast/upload?employeeData={Uri.EscapeDataString(empdata)}";

                            try
                            {
                                var request = new HttpRequestMessage(HttpMethod.Post, url);
                                request.Headers.Add("Accept", "*/*");

                                var response = await client.SendAsync(request);

                                if (response.IsSuccessStatusCode)
                                {
                                    var responseData = await response.Content.ReadAsStringAsync();
                                    Console.WriteLine("Success: " + responseData);

                                    return Ok(responseData);

                                }
                                else
                                {
                                    Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                                    return BadRequest(response.StatusCode);
                                }

                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Exception: " + ex.Message);
                                return View();
                            }

                        }
                    }
                }
                catch (XmlException xmlEx)
                {
                    ViewBag.Message = $"Error processing the XML file: {xmlEx.Message}";
                    return BadRequest(xmlEx.Message);
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"An unexpected error occurred: {ex.Message}";
                    return BadRequest(ex.Message);
                }

                
            }
            else
            {
                return BadRequest("No file uploaded.");
            }
        }

        /// ------------------------------------------------post end 






        [HttpGet]
        public async Task<ActionResult> Employee()
        {
            List<XMLUploadapp.Models.Employee> employees = new List<XMLUploadapp.Models.Employee>(); // Use the correct namespace

            try
            {

                var response = await client.GetStringAsync("http://localhost:53329/WeatherForecast/employees");

                employees = JsonConvert.DeserializeObject<List<XMLUploadapp.Models.Employee>>(response); // Use the correct namespace
            }
            catch (HttpRequestException e)
            {

                ViewBag.ErrorMessage = "Error fetching data: " + e.Message;
            }


            return View(employees);
        }

        [HttpGet]
        public async Task<ActionResult> Export()
        {
            List<XMLUploadapp.Models.Employee> employees = new List<XMLUploadapp.Models.Employee>(); // Use the correct namespace

            try
            {

                var response = await client.GetStringAsync("http://localhost:53329/WeatherForecast/employees");


                employees = JsonConvert.DeserializeObject<List<XMLUploadapp.Models.Employee>>(response); // Use the correct namespace
            }
            catch (HttpRequestException e)
            {

                ViewBag.ErrorMessage = "Error fetching data: " + e.Message;
            }


            var xmlData = ConvertToXml(employees);


            return File(new System.Text.UTF8Encoding().GetBytes(xmlData), "application/xml", "employees.xml");

        }
        private string ConvertToXml<T>(List<T> data)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<T>));
            using (StringWriter textWriter = new StringWriter())
            {
                xmlSerializer.Serialize(textWriter, data);
                return textWriter.ToString();
            }
        }

    }



    public class Employee
    {
        public string Name { get; set; }
        public string ID { get; set; }
        public string Contact { get; set; }
        public string BloodGroup { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
    }

    
}
